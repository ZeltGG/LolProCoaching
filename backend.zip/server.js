// server.js
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');

const authRoutes = require('./routes/auth');
const sessionRoutes = require('./routes/sessions');

dotenv.config();

const app = express();

// ✅ Middleware CORS mejorado
app.use((req, res, next) => {
  const allowedOrigins = ['http://localhost:4200', 'https://zeltgg.github.io'];
  const origin = req.headers.origin;

  if (allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
  }

  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

app.use(express.json());

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/sessions', sessionRoutes);

// Ruta raíz
app.get('/', (req, res) => {
  res.send('🚀 LoLProCoaching backend en línea y conectado a MongoDB Atlas');
});

// ✅ Conexión a MongoDB (sin opciones obsoletas)
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Conectado a MongoDB'))
  .catch(err => console.error('❌ Error conectando a MongoDB:', err));

// ✅ Exportar app para pruebas con Jest
module.exports = app;